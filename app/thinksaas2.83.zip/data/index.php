<?php
header('Content-Type: text/html; charset=UTF-8');
echo 'Thank you for using ThinkSAAS';
echo '<br />';
echo '<a style="color:#999" href="http://www.thinksaas.cn">www.thinksaas.cn</a>';
exit;
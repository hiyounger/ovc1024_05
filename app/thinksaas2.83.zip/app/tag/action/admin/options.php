<?php 
defined('IN_TS') or die('Access Denied.');

include template("admin/options");
<?php
defined('IN_TS') or die('Access Denied.');
return array(
	'name'	=> '同城',
	'version'	=> '1.2',
	'desc'	=> '同城APP',
	'url' => 'http://www.thinksaas.cn',
	'email' => 'thinksaas@qq.com',
	'author' => '邱君',
	'author_url' => 'http://www.thinksaas.cn',
	'isoption'	=> '1',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '1',
    'ismy'=>'1',
);
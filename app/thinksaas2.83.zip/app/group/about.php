<?php
defined('IN_TS') or die('Access Denied.');
return array(
	'name'	=> '小组',
	'version'	=> '1.2',
	'desc'	=> '小组，群组，BBS，社区讨论，创建小组，发表帖子',
	'url' => 'http://www.thinksaas.cn',
	'email' => 'thinksaas@qq.com',
	'author' => '邱君',
	'author_url' => 'http://www.thinksaas.cn',
	'isoption'	=> '1',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '1',
    'ismy'=>'1',
);
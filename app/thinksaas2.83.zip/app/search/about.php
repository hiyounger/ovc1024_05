<?php
defined('IN_TS') or die('Access Denied.');
return array(
	'name'	=> '搜索',
	'version'	=> '1.2',
	'desc'	=> '搜索APP',
	'url' => 'http://www.thinksaas.cn',
	'email' => 'thinksaas@qq.com',
	'author' => '邱君',
	'author_url' => 'http://www.thinksaas.cn',
	'isoption'	=> '0',
	'isinstall'	=> '1',
	'issql' => '1',
	'issystem'	=> '1',
	'isappnav'	=> '1',
    'ismy'=>'0',
);
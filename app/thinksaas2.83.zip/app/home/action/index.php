<?php
defined('IN_TS') or die('Access Denied.');


$title = $TS_SITE['site_subtitle'];
include template("index");
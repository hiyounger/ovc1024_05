<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/3/5
 * Time: 16:51
 */


$title = $TS_SITE['site_subtitle'];
include template('home');
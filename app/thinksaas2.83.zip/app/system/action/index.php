<?php
defined('IN_TS') or die('Access Denied.');

$title = '管理后台';
include template("admincp");
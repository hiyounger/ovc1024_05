<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/19
 * Time: 17:14
 */
defined('IN_TS') or die('Access Denied.');

phpinfo();
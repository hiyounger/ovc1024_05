<?php
defined('IN_TS') or die('Access Denied.');

$title = '后台登录';
include template('system');
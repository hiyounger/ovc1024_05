<?php 
defined ( 'IN_TS' ) or die ( 'Access Denied.' );


$title = '我的小组';
include template('my/index');
<?php
defined('IN_TS') or die('Access Denied.');
$skin = 'default';
require_once THINKDATA.'/config.inc.php';
	
$TS_APP['appname'] = '相册';
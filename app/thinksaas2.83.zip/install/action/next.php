<?php 
defined('IN_TS') or die('Access Denied.');

$site_url = getHttpUrl();

include 'install/html/next.html';
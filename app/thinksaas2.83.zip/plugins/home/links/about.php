<?php
defined('IN_TS') or die('Access Denied.');
//插件信息
return array(
    'hook'=>'home_index_footer', //钩子
    'name' => '友情连接插件',
    'version' => '1.0',
    'desc' => '开启友情连接插件后，将在首页显示友情链接',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isedit'	=> '1',
);
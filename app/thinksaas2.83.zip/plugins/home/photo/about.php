<?php
defined('IN_TS') or die('Access Denied.');
//插件信息
return array(
    'hook'=>'home_index_footer', //钩子
    'name' => '相册插件',
    'version' => '1.0',
    'desc' => '相册插件',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isedit'	=> '0',
);
<?php
defined('IN_TS') or die('Access Denied.');
//插件信息
return array(
    'hook'=>'home_index_right', //钩子
    'name' => '首页最新文章',
    'version' => '1.0',
    'desc' => '首页最新文章',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isedit'	=> '0',
);
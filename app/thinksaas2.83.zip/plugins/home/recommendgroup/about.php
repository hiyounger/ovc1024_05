<?php
defined('IN_TS') or die('Access Denied.');
return array(
    'hook'=>'home_index_left', //钩子
    'name' => '推荐小组',
    'version' => '1.0',
    'desc' => '推荐小组',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isedit'	=> '0',
);
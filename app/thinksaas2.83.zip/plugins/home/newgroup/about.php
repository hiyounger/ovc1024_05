<?php
defined('IN_TS') or die('Access Denied.');
//最新创建小组
return array(
    'hook'=>'home_index_right', //钩子
    'name' => '最新创建小组',
    'version' => '1.0',
    'desc' => '最新创建小组',
    'url' => 'http://www.thinksaas.cn',
    'email' => 'thinksaas@qq.com',
    'author' => '邱君',
    'author_url' => 'http://www.thinksaas.cn',
    'isedit'	=> '0',
);